| `Version` | `Update Notes`                                                                               |
|-----------|----------------------------------------------------------------------------------------------|
| 1.0.1     | - Tweak the readme to exclude a blerp about servers. My own Live Templates get me sometimes. |
| 1.0.0     | - Initial Release                                                                            |